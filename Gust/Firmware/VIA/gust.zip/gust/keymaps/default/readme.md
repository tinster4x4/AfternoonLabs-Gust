# Default Gust Layout

![Gust Layout Image](https://i.imgur.com/HfouVnS.png)

This is the default layout for Gust Macro Board.
